DROP TABLE IF EXISTS `#__brazitrac_greeting`;
 
CREATE TABLE `#__brazitrac_greeting` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `greeting` VARCHAR(25) NOT NULL,
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
 
INSERT INTO `#__brazitrac_greeting` (`greeting`) VALUES
        ('Hello World!'),
        ('Good bye World!');
DROP TABLE IF EXISTS `#__brazitrac_settings`;
 
CREATE TABLE `#__brazitrac_settings` (
		`name` varchar(255) NOT NULL default '',
		`value` varchar(255) default NULL,
		PRIMARY KEY  (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
 
INSERT INTO `#__brazitrac_settings` (`name`,`value`) VALUES
                                                        ('iconset','mdn_'),
                                                        ('highlight','!'),
                                                        ('enhighlight','1'),
                                                        ('ticketsfront','5'),
                                                        ('ticketssub','15'),
                                                        ('sourceemail',''),
                                                        ('msgbox','bbcode'),
                                                        ('name','BraziTrac Ticket System'),
                                                        ('users','0'),
                                                        ('agree','0'),
                                                        ('agreei',''),
                                                        ('agreelw','You must agree to the following terms to use this system'),
                                                        ('agreen','agreement'),
                                                        ('agreela','If you have read the terms please continue'),
                                                        ('agreeb','continue'),
                                                        ('view','a'),
                                                        ('msgboxh','10'),
                                                        ('msgboxw','58'),
                                                        ('msgboxt','1'),
                                                        ('dorganisation','individual'),
                                                        ('copyright','BraziTrac Ticket System for Mambo and Joomla'),
                                                        ('date','j-M-Y (h:i)'),
                                                        ('defaultmsg','type here...'),
                                                        ('dateshort','j-M-Y'),
                                                        ('assignname','Assigned Tickets'),
                                                        ('assigndescription','Tickets assigned to you to answer'),
                                                        ('assignimage',''),
                                                        ('versionmajor','3'),
                                                        ('versionminor','5'),
                                                        ('versionpatch','7'),
                                                        ('css','disable'),
                                                        ('versionname','stable'),
                                                        ('upgrade','0'),
                                                        ('userdefault','1'),
                                                        ('usersimport','0'),
                                                        ('debug','0'),
                                                        ('debugmessage','Continue >>');
                                                        