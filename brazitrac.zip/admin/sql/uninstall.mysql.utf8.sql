DROP TABLE IF EXISTS `#__brazitrac_greeting`;
DROP TABLE IF EXISTS `#__brazitrac_settings`;